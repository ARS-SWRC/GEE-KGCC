from .KGCC import KGCC

__version__ = "1.0.0"
__all__ = ["KGCC", "__version__"]


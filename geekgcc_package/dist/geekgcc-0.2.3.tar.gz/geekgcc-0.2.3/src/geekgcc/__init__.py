from .KGCC import KGCC

__version__ = "0.2.3"
__all__ = ["KGCC", "__version__"]


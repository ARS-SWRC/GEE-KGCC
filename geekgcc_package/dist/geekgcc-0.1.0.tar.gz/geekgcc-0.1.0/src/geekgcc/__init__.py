from .KGCC import KGCC

__version__ = "0.1.0"
__all__ = ["KGCC", "__version__"]


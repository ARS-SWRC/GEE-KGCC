# -*- coding: utf-8 -*-
"""
Created on Sun Sep 28 18:50:11 2025

@author: Andrew.Fullhart
"""


from .KGCC import KGCC
#from .KGCC import get_vis_palette
#from .KGCC import download

__version__ = "0.1.0"
__all__ = ["KGCC", "__version__"]

